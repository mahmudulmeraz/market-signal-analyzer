class SignalTerminalError(Exception):
    """Base application error."""


class DataValidationError(SignalTerminalError):
    pass


class ProviderError(SignalTerminalError):
    pass


class IndicatorError(SignalTerminalError):
    pass


class DatabaseError(SignalTerminalError):
    pass
