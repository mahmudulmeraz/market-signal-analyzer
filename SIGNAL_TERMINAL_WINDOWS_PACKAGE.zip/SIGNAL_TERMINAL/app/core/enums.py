from enum import Enum


class Direction(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    WAIT = "WAIT"


class Strength(str, Enum):
    NONE = "NONE"
    WEAK = "WEAK"
    MODERATE = "MODERATE"
    STRONG = "STRONG"


class SignalState(str, Enum):
    DEVELOPING = "DEVELOPING"
    CONFIRMED = "CONFIRMED"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    RESOLVED = "RESOLVED"


class DataMode(str, Enum):
    SIMULATED = "SIMULATED"
    LIVE_UNCONFIGURED = "LIVE_UNCONFIGURED"
    LIVE = "LIVE"


class TradingMode(str, Enum):
    RESEARCH = "RESEARCH"
    PAPER = "PAPER"


class TrendState(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    SIDEWAYS = "SIDEWAYS"
    UNCLEAR = "UNCLEAR"


class MaType(str, Enum):
    SMA = "SMA"
    EMA = "EMA"
