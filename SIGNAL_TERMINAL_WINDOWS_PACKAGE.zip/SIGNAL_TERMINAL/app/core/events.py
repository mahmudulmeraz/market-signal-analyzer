"""Typed event names used between workers and the Qt UI."""

CANDLE_CLOSED = "candle_closed"
PRICE_UPDATED = "price_updated"
SIGNAL_UPDATED = "signal_updated"
STATUS_UPDATED = "status_updated"
LOG_EVENT = "log_event"
PAPER_UPDATED = "paper_updated"
