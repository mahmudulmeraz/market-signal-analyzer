from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.core.enums import Direction, SignalState, Strength, TrendState


@dataclass
class Candle:
    symbol: str
    timeframe: str
    timestamp: int  # unix ms
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    is_closed: bool = True


@dataclass
class Tick:
    symbol: str
    timestamp: int
    last: float
    bid: Optional[float] = None
    ask: Optional[float] = None


@dataclass
class IndicatorSnapshot:
    rsi: Optional[float] = None
    rsi_state: str = "UNAVAILABLE"
    bb_upper: Optional[float] = None
    bb_middle: Optional[float] = None
    bb_lower: Optional[float] = None
    bb_width: Optional[float] = None
    bb_position: Optional[float] = None
    bb_state: str = "UNAVAILABLE"
    ma: Optional[float] = None
    ma_slope: Optional[float] = None
    trend: TrendState = TrendState.UNCLEAR
    fractal: str = "NONE"
    fractal_confirmed: bool = False
    zigzag: str = "NONE"
    zigzag_confirmed: bool = False


@dataclass
class Signal:
    id: str
    symbol: str
    timeframe: str
    timestamp: int
    direction: Direction
    strength: Strength
    score: float
    reasons: List[str]
    conflicts: List[str]
    snapshot: IndicatorSnapshot
    state: SignalState
    price: float
    valid_until: int
    outcome: Optional[str] = None
    pnl: Optional[float] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PaperTrade:
    id: str
    signal_id: str
    symbol: str
    timeframe: str
    direction: str
    entry_time: int
    entry_price: float
    bars_held: int = 0
    exit_time: Optional[int] = None
    exit_price: Optional[float] = None
    pnl: float = 0.0
    status: str = "OPEN"


@dataclass
class FractalPoint:
    index: int
    timestamp: int
    price: float
    kind: str  # BULLISH | BEARISH
    confirmed: bool


@dataclass
class ZigZagPoint:
    index: int
    timestamp: int
    price: float
    kind: str  # HIGH | LOW
    confirmed: bool
